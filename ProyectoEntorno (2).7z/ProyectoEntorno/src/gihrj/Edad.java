package gihrj;

public class Edad {
	
	    public static boolean esMayorDeEdad(int edad) {
	        return edad >= 18 && edad <= 100;
	    
	}

}

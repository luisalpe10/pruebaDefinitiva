/**
 * 
 */
/**
 * 
 */
module ProyectoEntorno {
	requires org.junit.jupiter.api;
}